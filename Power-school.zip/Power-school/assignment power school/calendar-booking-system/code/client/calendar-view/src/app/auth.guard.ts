import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(private router: Router) {}

  /**
   * Determines if a route can be activated based on the presence of a token in localStorage.
   * If token exists, allows navigation; otherwise, redirects to the sign-in page.
   * @returns {boolean} True if the route can be activated (token exists), false otherwise.
   */
  canActivate(): boolean {
    const token = localStorage.getItem('token');
    if (token) {
      return true; // Token exists, allow navigation
    } else {
      this.router.navigate(['/signin']); // No token, redirect to sign-in page
      return false; // Navigation not allowed
    }
  }
}
