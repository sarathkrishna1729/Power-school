export interface Appointment {
    _id?: string;
    title: string;
    date: string;
    startTime: string;
    endTime: string;
    status: string;
  }
  