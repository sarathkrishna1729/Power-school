import { Component, OnInit } from '@angular/core';
import { AppointmentService } from '../../services/appointment.service';
import { Appointment } from '../../models/appoinment.model';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-appointments',
  templateUrl: './appointments.component.html',
  styleUrls: ['./appointments.component.scss']
})
export class AppointmentsComponent implements OnInit {
  appointments: any[] = [];

  constructor(
    private appointmentService: AppointmentService,
    private router: Router,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.loadAppointments();
  }

  loadAppointments() {
    this.appointmentService.getAppointments().subscribe(
      resp => {
        if (resp.status == "success") {
          this.appointments = resp.data;
        } else {
          this.snackBar.open('Error fetching the appointments', 'Close', {
            duration: 3000,
          });
        }
        
      },
      error => {
        console.error('Error fetching appointments', error);
      }
    );
  }
  editAppointment(appointment: Appointment): void {

    this.router.navigate(['/appointment-form', appointment._id]);
  }
  deleteAppointment(id: string): void {
    if (confirm('Are you sure you want to delete this appointment?')) {
      this.appointmentService.deleteAppointment(id).subscribe(() => {
        this.snackBar.open('Appointment deleted successfully!', 'Close', {
          duration: 3000,
        });
        this.loadAppointments();
      });
    }
  }
}
