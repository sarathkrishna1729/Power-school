import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent {
  name: string = '';
  email: string = '';
  password: string = '';

  constructor(
    private userService: UserService,
    private router: Router,
    private snackBar: MatSnackBar
  ) {}

  signUp() {
    this.userService.signUp({ name: this.name, emailId: this.email, password: this.password }).subscribe(response => {
      console.log(response);
      if (response.status === "success") {
        this.snackBar.open('User registered successfully', 'Close', {
          duration: 3000,
        });
        this.router.navigate(['/signin']);
      }
    }, error => {
      if (error.error.message === "User already exists") {
        this.snackBar.open('User already exists', 'Close', {
          duration: 3000,
        });
      }
      console.error('Error signing up', error.message);
    });
  }

  onSubmit(signupForm: any): void {
    if (signupForm.valid) {
      this.signUp();
    } else {
      this.snackBar.open('Please fill out the form correctly', 'Close', {
        duration: 3000,
      });
    }
  }
}
