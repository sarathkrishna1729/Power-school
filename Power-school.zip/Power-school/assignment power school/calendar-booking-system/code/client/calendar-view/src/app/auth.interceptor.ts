import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  constructor() {}

  /**
   * Intercepts HTTP requests to add the 'x-auth-token' header if a token is present in localStorage.
   * @param req The original HTTP request.
   * @param next The next HTTP handler.
   * @returns An observable of the HTTP event.
   */
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const token = localStorage.getItem('token');
    if (token) {
      // Clone the request and add the 'x-auth-token' header
      const clonedReq = req.clone({
        headers: req.headers.set('x-auth-token', token)
      });
      return next.handle(clonedReq); // Pass the cloned request to the next handler
    }
    return next.handle(req); // No token, proceed with the original request
  }
}
