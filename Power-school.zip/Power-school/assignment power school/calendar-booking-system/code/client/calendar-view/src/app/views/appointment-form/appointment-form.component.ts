import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AppointmentService } from '../../services/appointment.service';
import { Appointment } from '../../models/appoinment.model';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Location } from '@angular/common';

@Component({
  selector: 'app-appointment-form',
  templateUrl: './appointment-form.component.html',
  styleUrls: ['./appointment-form.component.scss']
})
export class AppointmentFormComponent implements OnInit {
  isSaving: boolean = false;
  appointment: Appointment = {
    title: '',
    date: '',
    startTime: '',
    endTime: '',
    status: 'Scheduled'
  };
  isEditMode: boolean = false;

  constructor(
    private appointmentService: AppointmentService,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute,
    private router: Router,
    private location: Location
  ) {}

  ngOnInit(): void {
    // Retrieve appointment ID from route parameters
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEditMode = true;
      // Fetch appointment details by ID if in edit mode
      this.appointmentService.getAppointmentById(id).subscribe(
        (resp: any) => {
          if (resp.status === "success") {
            let appointment: Appointment = resp.data;
            // Format the date to display properly in the form
            this.appointment = {
              ...appointment,
              date: new Date(appointment.date).toISOString().substring(0, 10)
            };
          } else {
            this.snackBar.open('Error fetching appointment', 'Close', { duration: 3000 });
          }
        },
        error => {
          console.error('Error fetching appointment:', error);
          this.snackBar.open('Error fetching appointment', 'Close', { duration: 3000 });
        }
      );
    }
  }

  onSubmit(form: NgForm): void {
    this.isSaving = true;
    if (form.valid && this.isValidTime()) {
      if (this.appointment._id) {
        // Update existing appointment
        this.appointmentService.updateAppointment(this.appointment).subscribe(
          response => {
            console.log('Appointment updated successfully:', response);
            this.snackBar.open('Appointment updated successfully', 'Close', { duration: 3000 });
            this.isSaving = false;
          },
          error => {
            console.error('Error updating appointment:', error);
            this.snackBar.open('Error updating appointment', 'Close', { duration: 3000 });
            this.isSaving = false;
          }
        );
      } else {
        // Add new appointment
        this.appointmentService.addAppointment(this.appointment).subscribe(
          response => {
            console.log('Appointment added successfully:', response);
            form.resetForm();
            this.snackBar.open('Appointment added successfully', 'Close', { duration: 3000 });
          },
          error => {
            console.error('Error adding appointment:', error);
          }
        );
      }
    }
  }

  goBack(): void {
    // Navigate back to the previous location
    this.location.back();
  }

  isValidTime(): boolean {
    // Check if end time is after start time
    const startDateTime = new Date(`${this.appointment.date}T${this.appointment.startTime}`);
    const endDateTime = new Date(`${this.appointment.date}T${this.appointment.endTime}`);
    return endDateTime > startDateTime;
  }
}
