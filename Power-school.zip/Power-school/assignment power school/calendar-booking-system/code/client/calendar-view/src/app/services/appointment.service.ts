import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Appointment } from '../models/appoinment.model';
@Injectable({
  providedIn: 'root'
})
export class AppointmentService {
  private baseUrl = 'http://localhost:5000/api/appointments';

  constructor(private http: HttpClient) { }

  getAppointments(): Observable<any> {
    return this.http.get(this.baseUrl);
  }

  addAppointment(appointment: any): Observable<any> {
    return this.http.post(this.baseUrl, appointment);
  }

  updateAppointment(appointment: Appointment): Observable<Appointment> {
    return this.http.put<Appointment>(`${this.baseUrl}/${appointment._id}`, appointment);
  }

  deleteAppointment(appointmentId: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${appointmentId}`);
  }
  getAppointmentById(id: string): Observable<Appointment> {
    return this.http.get<Appointment>(`${this.baseUrl}/${id}`);
  }

}
