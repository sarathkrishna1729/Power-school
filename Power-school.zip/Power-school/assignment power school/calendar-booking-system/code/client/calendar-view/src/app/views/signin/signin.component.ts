import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss']
})
export class SigninComponent implements OnInit {
  email: string = '';
  password: string = '';

  constructor(
    private userService: UserService,
    private router: Router,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    // Check if token exists on component initialization
    const token = localStorage.getItem('token');
    if (token) {
      this.router.navigate(['/appointments']); // Redirect if token exists
    }
  }

  // Method to handle user sign-in
  signIn() {
    this.userService.signIn({ emailId: this.email, password: this.password }).subscribe(
      response => {
        if (response.status === "success") {
          this.snackBar.open('User Login successfully', 'Close', {
            duration: 3000,
          });
          localStorage.setItem('token', response.data.token); // Store token in localStorage
          this.router.navigate(['/appointments']); // Redirect on successful login
        } else {
          this.snackBar.open(response.message, 'Close', {
            duration: 3000,
          });
        }
      },
      error => {
        console.log(error);
        if (error.error.message === "Invalid Credentials") {
          this.snackBar.open('Invalid Credentials', 'Close', {
            duration: 3000,
          });
        }
      }
    );
  }

  // Method to navigate to the sign-up page
  navigateToSignup(): void {
    this.router.navigate(['/signup']);
  }
}
